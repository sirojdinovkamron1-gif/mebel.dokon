const state = {
  lang: localStorage.getItem("mebelon-lang") || "uz",
  products: [],
  filter: "all",
  search: "",
  sort: "popular",
  cart: JSON.parse(localStorage.getItem("mebelon-cart") || "[]"),
  wishlist: JSON.parse(localStorage.getItem("mebelon-wishlist") || "[]")
};

const i18n = {
  uz: {
    announce:"Bepul yetkazib berish — 3 000 000 so'mdan yuqori buyurtmalarga",navHome:"Bosh sahifa",navCatalog:"Katalog",navAbout:"Biz haqimizda",navServices:"Xizmatlar",navContacts:"Aloqa",
    heroEyebrow:"UYINGIZ UCHUN TANLANGAN",heroTitle1:"Uyingizga",heroTitle2:"xarakter",heroTitle3:"bering.",heroText:"Minimalizm, qulaylik va sifat bir joyda. Interyeringiz uchun dizaynerlar tanlagan mebellar kolleksiyasi.",
    shopNow:"Kolleksiyani ko'rish",learnMore:"Biz haqimizda →",statYears:"yil tajriba",statRating:"mijoz bahosi",statClients:"mijozlar",heroFrom:"Kolleksiya",newSeason:"Yangi mavsum",
    browse:"KATEGORIYALAR",browseTitle:"Har bir xona uchun.",viewAll:"Barchasini ko'rish →",catSofas:"Divanlar",catBeds:"Yotoqxona",catTables:"Stollar",catChairs:"Kreslolar",catStorage:"Shkaflar",
    collection:"KOLEKSIYA",collectionTitle:"Tanlangan mebellar.",all:"Barchasi",sortPopular:"Mashhur",sortLow:"Narx: arzon → qimmat",sortHigh:"Narx: qimmat → arzon",sortRating:"Reyting",nothingFound:"Hech narsa topilmadi",tryAnother:"Boshqa so'z yoki kategoriya bilan sinab ko'ring.",
    aboutKicker:"MEBELON FALSAFASI",aboutTitle:"Chiroyli uy — bu his.",aboutText:"Biz mebelni shunchaki buyum emas, har kuni his qilinadigan qulay muhit deb bilamiz. Har bir detal uzoq xizmat qilishi va interyer bilan uyg'unlashishi uchun o'ylab yaratiladi.",
    point1:"Tabiiy materiallar",point2:"Qulay ergonomika",point3:"Individual buyurtma",ourServices:"Xizmatlarimiz",
    serviceKicker:"XIZMATLAR",serviceTitle:"Sotib olishdan keyin ham yoningizdamiz.",srv1Title:"Yetkazib berish",srv1Text:"Toshkent bo'ylab tez va ehtiyotkor yetkazib berish xizmati.",srv2Title:"Montaj",srv2Text:"Mutaxassislarimiz mebelni uyda to'g'ri yig'ib beradi.",srv3Title:"Dizayn konsultatsiya",srv3Text:"Xonangiz uchun rang, shakl va joylashuv bo'yicha maslahat.",srv4Title:"Kafolat",srv4Text:"Sifatli mahsulot va ishonchli kafolat bilan xarid qiling.",more:"Batafsil →",
    quote:"Uy — qaytishni xohlaydigan joy. Biz shu tuyg'uni yaratishga yordam beramiz.",quoteSmall:"Interyerga yangi qarash",
    contactKicker:"ALOQA",contactTitle:"Loyihangiz haqida gaplashamiz.",contactText:"Savolingiz bormi? Formani yuboring yoki bizga qo'ng'iroq qiling.",address:"Toshkent, Chilonzor",formName:"Ismingiz",formPhone:"Telefon",formMessage:"Xabaringiz",send:"Yuborish ↗",formAddress:"Manzil",formNote:"Izoh",
    footerText:"Zamonaviy uylar uchun o'ylangan mebel.",madeWith:"Sifat bilan yaratilgan.",cartTitle:"Savat",wishTitle:"Sevimlilar",total:"Jami",checkout:"Buyurtma berish",checkoutKicker:"BUYURTMA",checkoutTitle:"Buyurtmani yakunlash",confirmOrder:"Buyurtmani tasdiqlash ↗",searchPlaceholder:"Mahsulot qidiring...",addedCart:"Savatga qo'shildi",addedWish:"Sevimlilarga qo'shildi",removedWish:"Sevimlilardan olib tashlandi",emptyCart:"Savatingiz bo'sh",emptyWish:"Hozircha sevimlilar yo'q",sent:"Murojaatingiz yuborildi",orderOk:"Buyurtma qabul qilindi",orderId:"Buyurtma raqami"
  },
  ru: {
    announce:"Бесплатная доставка — при заказах от 3 000 000 сум",navHome:"Главная",navCatalog:"Каталог",navAbout:"О нас",navServices:"Услуги",navContacts:"Контакты",
    heroEyebrow:"ВЫБРАНО ДЛЯ ВАШЕГО ДОМА",heroTitle1:"Добавьте дому",heroTitle2:"характер",heroTitle3:"и уют.",heroText:"Минимализм, комфорт и качество в одном месте. Коллекция мебели, выбранная дизайнерами для современного интерьера.",
    shopNow:"Смотреть коллекцию",learnMore:"О нас →",statYears:"лет опыта",statRating:"оценка клиентов",statClients:"клиентов",heroFrom:"Коллекция",newSeason:"Новый сезон",
    browse:"КАТЕГОРИИ",browseTitle:"Для каждой комнаты.",viewAll:"Смотреть всё →",catSofas:"Диваны",catBeds:"Спальни",catTables:"Столы",catChairs:"Кресла",catStorage:"Хранение",
    collection:"КОЛЛЕКЦИЯ",collectionTitle:"Избранная мебель.",all:"Все",sortPopular:"Популярные",sortLow:"Цена: по возрастанию",sortHigh:"Цена: по убыванию",sortRating:"Рейтинг",nothingFound:"Ничего не найдено",tryAnother:"Попробуйте другое слово или категорию.",
    aboutKicker:"ФИЛОСОФИЯ MEBELON",aboutTitle:"Красивый дом — это ощущение.",aboutText:"Мы считаем мебель не просто предметом, а комфортной атмосферой, которую вы чувствуете каждый день. Каждая деталь продумана для долговечности и гармонии с интерьером.",
    point1:"Натуральные материалы",point2:"Эргономичный комфорт",point3:"Индивидуальный заказ",ourServices:"Наши услуги",
    serviceKicker:"УСЛУГИ",serviceTitle:"Мы рядом и после покупки.",srv1Title:"Доставка",srv1Text:"Быстрая и аккуратная доставка по Ташкенту.",srv2Title:"Монтаж",srv2Text:"Наши специалисты правильно соберут мебель дома.",srv3Title:"Консультация дизайнера",srv3Text:"Поможем подобрать цвет, форму и расположение.",srv4Title:"Гарантия",srv4Text:"Покупайте качественную мебель с гарантией.",more:"Подробнее →",
    quote:"Дом — это место, куда хочется возвращаться. Мы помогаем создать это ощущение.",quoteSmall:"Новый взгляд на интерьер",
    contactKicker:"КОНТАКТЫ",contactTitle:"Поговорим о вашем проекте.",contactText:"Есть вопрос? Отправьте форму или позвоните нам.",address:"Ташкент, Чиланзар",formName:"Ваше имя",formPhone:"Телефон",formMessage:"Сообщение",send:"Отправить ↗",formAddress:"Адрес",formNote:"Комментарий",
    footerText:"Мебель, продуманная для современного дома.",madeWith:"Создано с вниманием к качеству.",cartTitle:"Корзина",wishTitle:"Избранное",total:"Итого",checkout:"Оформить заказ",checkoutKicker:"ЗАКАЗ",checkoutTitle:"Оформление заказа",confirmOrder:"Подтвердить заказ ↗",searchPlaceholder:"Найдите товар...",addedCart:"Добавлено в корзину",addedWish:"Добавлено в избранное",removedWish:"Удалено из избранного",emptyCart:"Корзина пуста",emptyWish:"Пока нет избранных товаров",sent:"Сообщение отправлено",orderOk:"Заказ принят",orderId:"Номер заказа"
  },
  en: {
    announce:"Free delivery — for orders above 3,000,000 UZS",navHome:"Home",navCatalog:"Catalog",navAbout:"About us",navServices:"Services",navContacts:"Contact",
    heroEyebrow:"CURATED FOR YOUR HOME",heroTitle1:"Give your home",heroTitle2:"character",heroTitle3:"and comfort.",heroText:"Minimalism, comfort and quality in one place. A furniture collection selected by designers for modern interiors.",
    shopNow:"Explore collection",learnMore:"About us →",statYears:"years of experience",statRating:"customer rating",statClients:"happy clients",heroFrom:"Collection",newSeason:"New season",
    browse:"CATEGORIES",browseTitle:"For every room.",viewAll:"View everything →",catSofas:"Sofas",catBeds:"Bedrooms",catTables:"Tables",catChairs:"Armchairs",catStorage:"Storage",
    collection:"COLLECTION",collectionTitle:"Selected furniture.",all:"All",sortPopular:"Popular",sortLow:"Price: low → high",sortHigh:"Price: high → low",sortRating:"Rating",nothingFound:"Nothing found",tryAnother:"Try another keyword or category.",
    aboutKicker:"MEBELON PHILOSOPHY",aboutTitle:"A beautiful home is a feeling.",aboutText:"We see furniture as more than objects — it is an atmosphere you experience every day. Every detail is designed for durability and harmony with your interior.",
    point1:"Natural materials",point2:"Ergonomic comfort",point3:"Custom orders",ourServices:"Our services",
    serviceKicker:"SERVICES",serviceTitle:"We stay with you after the purchase.",srv1Title:"Delivery",srv1Text:"Fast, careful delivery across Tashkent.",srv2Title:"Assembly",srv2Text:"Our specialists assemble your furniture at home.",srv3Title:"Design consultation",srv3Text:"Advice on colors, shapes and room layout.",srv4Title:"Warranty",srv4Text:"Shop quality furniture with confidence.",more:"Learn more →",
    quote:"Home is the place you want to return to. We help you create that feeling.",quoteSmall:"A new perspective on interiors",
    contactKicker:"CONTACT",contactTitle:"Let's talk about your project.",contactText:"Have a question? Send the form or call us.",address:"Tashkent, Chilonzor",formName:"Your name",formPhone:"Phone",formMessage:"Message",send:"Send ↗",formAddress:"Address",formNote:"Note",
    footerText:"Furniture thoughtfully made for modern homes.",madeWith:"Made with attention to quality.",cartTitle:"Cart",wishTitle:"Wishlist",total:"Total",checkout:"Checkout",checkoutKicker:"ORDER",checkoutTitle:"Complete your order",confirmOrder:"Confirm order ↗",searchPlaceholder:"Search products...",addedCart:"Added to cart",addedWish:"Added to wishlist",removedWish:"Removed from wishlist",emptyCart:"Your cart is empty",emptyWish:"No favorites yet",sent:"Message sent",orderOk:"Order received",orderId:"Order number"
  }
};

const money = n => `${new Intl.NumberFormat("uz-UZ").format(n)} so'm`;
const tr = key => i18n[state.lang][key] ?? key;
const save = () => {
  localStorage.setItem("mebelon-cart", JSON.stringify(state.cart));
  localStorage.setItem("mebelon-wishlist", JSON.stringify(state.wishlist));
  localStorage.setItem("mebelon-lang", state.lang);
};

function applyLanguage(){
  document.documentElement.lang = state.lang;
  document.querySelectorAll("[data-i18n]").forEach(el => { el.textContent = tr(el.dataset.i18n); });
  document.querySelectorAll("[data-placeholder]").forEach(el => { el.placeholder = tr(el.dataset.placeholder); });
  document.getElementById("langButton").textContent = state.lang.toUpperCase();
  renderProducts();
  renderCart();
  renderWishlist();
}

async function init(){
  try{
    const res = await fetch("/api/products");
    state.products = await res.json();
    renderProducts();
    updateCounts();
  }catch(e){
    document.getElementById("productsGrid").innerHTML = "<p>Products could not be loaded.</p>";
  }
  setupEvents();
  observeReveals();
  applyLanguage();
}

function productTitle(p){ return p.name[state.lang] || p.name.uz; }
function categoryTitle(p){ return p.categoryLabel[state.lang] || p.categoryLabel.uz; }

function renderProducts(){
  const grid = document.getElementById("productsGrid");
  let list = state.products.filter(p => state.filter==="all" ? true : p.category===state.filter);
  if(state.search){
    const q = state.search.toLowerCase();
    list = list.filter(p => Object.values(p.name).some(v => v.toLowerCase().includes(q)));
  }
  if(state.sort==="low") list.sort((a,b)=>a.price-b.price);
  if(state.sort==="high") list.sort((a,b)=>b.price-a.price);
  if(state.sort==="rating") list.sort((a,b)=>b.rating-a.rating);
  document.getElementById("productResult").textContent = `${list.length} ${state.lang==="ru"?"товаров":state.lang==="en"?"items":"mahsulot"}`;
  document.getElementById("emptyState").classList.toggle("hidden", list.length>0);
  grid.innerHTML = list.map(productCard).join("");
}

function productCard(p){
  const wished = state.wishlist.includes(p.id);
  const badge = p.badge ? `<span class="badge">${p.badge==="new"?"NEW":p.badge==="hit"?"HIT":"SALE"}</span>` : "";
  return `<article class="product-card reveal in">
    <div class="product-media" data-product="${p.id}"><img src="${p.image}" alt="${escapeHtml(productTitle(p))}" loading="lazy" onerror="this.onerror=null;this.src='https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=85';">${badge}<button class="wish-btn ${wished?"active":""}" data-wish="${p.id}" aria-label="favorite">${wished?"♥":"♡"}</button></div>
    <div class="product-info"><div class="product-category">${escapeHtml(categoryTitle(p))}</div><div class="product-name">${escapeHtml(productTitle(p))}</div>
      <div class="product-bottom"><div class="price"><strong>${money(p.price)}</strong>${p.oldPrice?`<s>${money(p.oldPrice)}</s>`:""}</div><div class="rating">★ ${p.rating}</div><button class="quick-add" data-add="${p.id}" aria-label="add to cart">+</button></div>
    </div></article>`;
}
function escapeHtml(s){ return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[m])); }

function findProduct(id){ return state.products.find(p=>p.id===Number(id)); }

function addCart(id){
  const item = state.cart.find(x=>x.id===Number(id));
  if(item) item.qty++;
  else state.cart.push({id:Number(id),qty:1});
  save(); renderCart(); updateCounts(); toast(tr("addedCart"));
}
function addWish(id){
  id=Number(id);
  if(state.wishlist.includes(id)){
    state.wishlist=state.wishlist.filter(x=>x!==id); toast(tr("removedWish"));
  }else{state.wishlist.push(id);toast(tr("addedWish"));}
  save(); renderProducts(); renderWishlist(); updateCounts();
}
function updateCounts(){
  document.getElementById("cartCount").textContent = state.cart.reduce((sum,x)=>sum+x.qty,0);
  document.getElementById("wishCount").textContent = state.wishlist.length;
}
function renderCart(){
  const wrap=document.getElementById("cartItems");
  if(!state.cart.length){wrap.innerHTML=`<div class="empty-cart">${tr("emptyCart")}</div>`;document.getElementById("cartTotal").textContent=money(0);document.getElementById("checkoutTotal").textContent=money(0);return;}
  let total=0;
  wrap.innerHTML=state.cart.map(item=>{
    const p=findProduct(item.id); if(!p)return "";
    total+=p.price*item.qty;
    return `<div class="cart-item"><img src="${p.image}" alt=""><div><h4>${escapeHtml(productTitle(p))}</h4><small>${money(p.price)}</small><div class="qty"><button data-qty="${p.id}" data-change="-1">−</button><b>${item.qty}</b><button data-qty="${p.id}" data-change="1">+</button></div></div><button class="remove-btn" data-remove="${p.id}">×</button></div>`;
  }).join("");
  document.getElementById("cartTotal").textContent=money(total); document.getElementById("checkoutTotal").textContent=money(total);
}
function renderWishlist(){
  const wrap=document.getElementById("wishlistItems");
  const list=state.wishlist.map(findProduct).filter(Boolean);
  if(!list.length){wrap.innerHTML=`<div class="empty-cart">${tr("emptyWish")}</div>`;return;}
  wrap.innerHTML=list.map(p=>`<div class="wish-item"><img src="${p.image}" alt=""><div><h4>${escapeHtml(productTitle(p))}</h4><small>${money(p.price)}</small><div style="margin-top:9px"><button class="btn btn-outline" style="min-height:34px;padding:0 13px;font-size:10px" data-add="${p.id}">${tr("checkout")}</button></div></div><button class="remove-btn" data-wish="${p.id}">×</button></div>`).join("");
}

function openDrawer(id){
  closeAll();
  document.getElementById(id).classList.add("open");
  document.getElementById("overlay").classList.add("show");
  document.body.classList.add("locked");
}
function openModal(id){
  closeAll();
  document.getElementById(id).classList.add("show");
  document.getElementById("overlay").classList.add("show");
  document.body.classList.add("locked");
}
function closeAll(){
  document.querySelectorAll(".drawer.open,.modal.show").forEach(el=>el.classList.remove("open","show"));
  document.getElementById("overlay").classList.remove("show"); document.body.classList.remove("locked");
}

function openProduct(id){
  const p=findProduct(id); if(!p)return;
  document.getElementById("productModalContent").innerHTML=`
   <div class="product-detail"><div class="product-detail-image"><img src="${p.image}" alt="${escapeHtml(productTitle(p))}"></div>
   <div class="product-detail-copy"><div class="product-category">${escapeHtml(categoryTitle(p))}</div><h2>${escapeHtml(productTitle(p))}</h2><div class="detail-price">${money(p.price)} ${p.oldPrice?`<s style="font-size:13px;color:#998f84;font-weight:400">${money(p.oldPrice)}</s>`:""}</div><div class="detail-rating">★★★★★ &nbsp; ${p.rating}/5</div>
   <p class="detail-desc">${detailDescription(p)}</p><div class="detail-meta"><span>✓ ${state.lang==="ru"?"Гарантия 12 месяцев":state.lang==="en"?"12-month warranty":"12 oylik kafolat"}</span><span>✓ ${state.lang==="ru"?"Бесплатный замер":state.lang==="en"?"Free measurement":"Bepul o'lchov"}</span><span>✓ ${state.lang==="ru"?"Доставка по Ташкенту":state.lang==="en"?"Tashkent delivery":"Toshkent bo'ylab yetkazib berish"}</span></div><button class="btn btn-dark full" style="margin-top:28px" data-add="${p.id}">${state.lang==="ru"?"Добавить в корзину":state.lang==="en"?"Add to cart":"Savatga qo'shish"} ↗</button></div></div>`;
  openModal("productModal");
}
function detailDescription(p){
  const texts = {
    uz:`${productTitle(p)} — zamonaviy interyer uchun ishlab chiqilgan qulay va mustahkam model. Materiallar, o'lcham va ranglar kolleksiya uslubiga mos tanlangan.`,
    ru:`${productTitle(p)} — удобная и надежная модель для современного интерьера. Материалы, размеры и оттенки подобраны в едином стиле коллекции.`,
    en:`${productTitle(p)} is a comfortable, durable piece created for modern interiors. Materials, dimensions and colors are selected to fit the collection style.`
  }; return texts[state.lang];
}

function getTotal(){ return state.cart.reduce((sum,x)=>{const p=findProduct(x.id);return sum+(p?p.price*x.qty:0)},0); }
function toast(msg){const el=document.getElementById("toast");el.textContent=msg;el.classList.add("show");clearTimeout(window.__toast);window.__toast=setTimeout(()=>el.classList.remove("show"),2400);}

function setupEvents(){
  document.addEventListener("click", e=>{
    const add=e.target.closest("[data-add]"); if(add){addCart(add.dataset.add); return;}
    const wish=e.target.closest("[data-wish]"); if(wish){addWish(wish.dataset.wish); return;}
    const media=e.target.closest("[data-product]"); if(media && !e.target.closest("[data-wish]")){openProduct(media.dataset.product); return;}
    const qty=e.target.closest("[data-qty]"); if(qty){const item=state.cart.find(x=>x.id===Number(qty.dataset.qty));if(item){item.qty+=Number(qty.dataset.change);if(item.qty<=0)state.cart=state.cart.filter(x=>x!==item);save();renderCart();updateCounts();}return;}
    const rem=e.target.closest("[data-remove]");if(rem){state.cart=state.cart.filter(x=>x.id!==Number(rem.dataset.remove));save();renderCart();updateCounts();return;}
    const close=e.target.closest("[data-close]");if(close){closeAll();return;}
    const cat=e.target.closest("[data-category]");if(cat){state.filter=cat.dataset.category;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x.dataset.filter===state.filter));document.getElementById("catalog").scrollIntoView({behavior:"smooth"});renderProducts();return;}
    if(e.target.id==="overlay")closeAll();
  });
  document.getElementById("langButton").addEventListener("click",()=>document.querySelector(".lang-select").classList.toggle("open"));
  document.querySelectorAll("[data-lang]").forEach(b=>b.addEventListener("click",()=>{state.lang=b.dataset.lang;document.querySelector(".lang-select").classList.remove("open");save();applyLanguage();}));
  document.getElementById("cartOpen").addEventListener("click",()=>openDrawer("cartDrawer"));
  document.getElementById("wishlistOpen").addEventListener("click",()=>openDrawer("wishlistDrawer"));
  document.getElementById("checkoutBtn").addEventListener("click",()=>{if(!state.cart.length){toast(tr("emptyCart"));return;}openModal("checkoutModal");});
  document.getElementById("searchOpen").addEventListener("click",()=>{document.getElementById("searchPanel").classList.add("open");setTimeout(()=>document.getElementById("searchInput").focus(),180);});
  document.getElementById("searchClose").addEventListener("click",()=>{document.getElementById("searchPanel").classList.remove("open");state.search="";document.getElementById("searchInput").value="";renderProducts();});
  document.getElementById("searchInput").addEventListener("input",e=>{state.search=e.target.value.trim();renderProducts();});
  document.getElementById("sortSelect").addEventListener("change",e=>{state.sort=e.target.value;renderProducts();});
  document.querySelectorAll(".filter").forEach(b=>b.addEventListener("click",()=>{state.filter=b.dataset.filter;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderProducts();}));
  document.getElementById("mobileMenuBtn").addEventListener("click",()=>document.getElementById("mobileMenu").classList.toggle("open"));
  document.querySelectorAll(".mobile-menu a").forEach(a=>a.addEventListener("click",()=>document.getElementById("mobileMenu").classList.remove("open")));
  document.getElementById("announceClose").addEventListener("click",e=>e.target.closest(".announcement").remove());
  document.addEventListener("keydown",e=>{if(e.key==="Escape")closeAll();});
  document.getElementById("contactForm").addEventListener("submit",async e=>{
    e.preventDefault(); const fd=new FormData(e.target); const payload=Object.fromEntries(fd.entries());
    try{const r=await fetch("/api/contact",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});if(!r.ok)throw 0;e.target.reset();toast(tr("sent"));}catch{toast("Error");}
  });
  document.getElementById("checkoutForm").addEventListener("submit",async e=>{
    e.preventDefault();
    const fd=new FormData(e.target); const data=Object.fromEntries(fd.entries());
    const items=state.cart.map(x=>{const p=findProduct(x.id);return {id:p.id,name:p.name.uz,qty:x.qty,price:p.price};});
    try{
      const r=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({...data,items,total:getTotal()})});
      const out=await r.json(); if(!r.ok) throw new Error(out.message||"Error");
      state.cart=[]; save(); renderCart(); updateCounts(); closeAll(); e.target.reset(); toast(`${tr("orderOk")} — ${tr("orderId")}: ${out.orderId}`);
    }catch(err){toast(err.message||"Error");}
  });
}

function observeReveals(){
  const io=new IntersectionObserver(entries=>entries.forEach(x=>{if(x.isIntersecting){x.target.classList.add("in");io.unobserve(x.target)}}),{threshold:.08});
  document.querySelectorAll(".reveal").forEach(el=>io.observe(el));
}
window.addEventListener("scroll",()=>{const h=document.documentElement;const pct=(h.scrollTop/(h.scrollHeight-h.clientHeight))*100;document.getElementById("scrollProgress").style.width=pct+"%";document.getElementById("header").classList.toggle("scrolled",h.scrollTop>20);});
init();
