# MEBELON — Professional Furniture Store

## Stack
- Node.js + Express
- HTML5 / CSS3 / Vanilla JavaScript
- JSON storage
- Telegram Bot API integration

## Ishga tushirish

```bash
npm install
```

`.env.example` faylidan nusxa olib `.env` yarating:

```bash
cp .env.example .env
```

`.env` ichiga:

```env
TELEGRAM_BOT_TOKEN=123456:ABC...
TELEGRAM_CHAT_ID=123456789
PORT=3000
```

so'ng:

```bash
npm start
```

Brauzer:

```text
http://localhost:3000
```

## Telegram ulanishi

1. Telegram'da `@BotFather` ga kiring.
2. `/newbot` yuboring va bot yarating.
3. Bot tokenini oling.
4. Buyurtmalar tushadigan shaxsiy chat yoki guruhni tanlang.
5. Botni o'sha guruhga qo'shsangiz, unga xabar yuborish huquqi bo'lsin.
6. `TELEGRAM_CHAT_ID` ni `.env` ga yozing.
7. Saytdan test buyurtma bering.

Har bir yangi buyurtmada Telegram'ga quyidagilar keladi:
- buyurtma raqami
- mijoz ismi
- telefon
- manzil
- mahsulotlar va soni
- umumiy summa
- izoh
- buyurtma vaqti

Muhim: `.env` faylini GitHub'ga joylamang. Bot tokenini hech kimga yubormang. Token oshkor bo'lib qolsa, BotFather orqali yangi token oling.

## Ishlaydigan funksiyalar
- O'zbek / Русский / English
- Responsive desktop / tablet / mobile
- Mahsulot katalogi
- Kategoriya filteri
- Qidiruv
- Saralash
- Mahsulot detail modal
- Savat + quantity
- Sevimlilar
- LocalStorage
- Checkout formasi
- Buyurtmalar `data/orders.json` ga saqlanadi
- Telegram botga avtomatik buyurtma yuborish
- Contact form
- Scroll/reveal animatsiyalar
- Mobile menu
- Search panel
- Toast notifications

## Eslatma
Demo mahsulot rasmlari Unsplash URL'lari orqali yuklanadi. Real loyiha uchun lokal rasmlarga almashtirish mumkin.
