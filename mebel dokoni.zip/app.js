require("dotenv").config();

const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const ORDERS_FILE = path.join(ROOT, "data", "orders.json");

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(ROOT, "public")));

function readOrders() {
  try {
    return JSON.parse(fs.readFileSync(ORDERS_FILE, "utf8"));
  } catch {
    return [];
  }
}

function saveOrders(orders) {
  fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2), "utf8");
}

function escapeTelegramHtml(value = "") {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function formatMoney(value) {
  return new Intl.NumberFormat("uz-UZ").format(Number(value) || 0) + " so'm";
}

async function sendTelegramOrder(order) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    console.warn("Telegram sozlanmagan: TELEGRAM_BOT_TOKEN yoki TELEGRAM_CHAT_ID yo'q.");
    return { ok: false, skipped: true };
  }

  const itemsText = order.items.map((item, index) => {
    const subtotal = (Number(item.price) || 0) * (Number(item.qty) || 0);
    return `${index + 1}. <b>${escapeTelegramHtml(item.name)}</b>\n   ${item.qty} dona × ${formatMoney(item.price)} = <b>${formatMoney(subtotal)}</b>`;
  }).join("\n\n");

  const date = new Date(order.createdAt).toLocaleString("uz-UZ", {
    timeZone: "Asia/Tashkent",
    hour12: false
  });

  const message =
`🛋 <b>YANGI MEBEL BUYURTMASI</b>

🆔 <b>Buyurtma:</b> ${escapeTelegramHtml(order.id)}
👤 <b>Mijoz:</b> ${escapeTelegramHtml(order.customer)}
📞 <b>Telefon:</b> ${escapeTelegramHtml(order.phone)}
📍 <b>Manzil:</b> ${escapeTelegramHtml(order.address)}

🛒 <b>Mahsulotlar:</b>
${itemsText}

💰 <b>JAMI:</b> ${formatMoney(order.total)}
📝 <b>Izoh:</b> ${escapeTelegramHtml(order.note || "Izoh yo'q")}
🕐 <b>Vaqt:</b> ${escapeTelegramHtml(date)}

✅ Saytdan yangi buyurtma kelib tushdi.`;

  const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: chatId,
      text: message,
      parse_mode: "HTML"
    })
  });

  const data = await response.json();

  if (!response.ok || !data.ok) {
    throw new Error(data.description || "Telegram xabar yuborilmadi");
  }

  return { ok: true };
}

app.get("/api/products", (req, res) => {
  res.sendFile(path.join(ROOT, "public", "data", "products.json"));
});

app.post("/api/orders", async (req, res) => {
  const { customer, phone, address, items, total, note } = req.body || {};

  if (!customer || !phone || !address || !Array.isArray(items) || !items.length) {
    return res.status(400).json({
      ok: false,
      message: "Buyurtma ma'lumotlari to'liq emas."
    });
  }

  const orders = readOrders();

  const order = {
    id: `MB-${Date.now().toString().slice(-8)}`,
    createdAt: new Date().toISOString(),
    status: "new",
    customer: String(customer).trim(),
    phone: String(phone).trim(),
    address: String(address).trim(),
    note: String(note || "").trim(),
    items,
    total: Number(total) || 0
  };

  orders.unshift(order);
  saveOrders(orders);

  try {
    await sendTelegramOrder(order);
    return res.status(201).json({ ok: true, orderId: order.id, telegramSent: true });
  } catch (error) {
    console.error("Telegram error:", error.message);
    // Buyurtma baribir JSON bazaga saqlandi.
    return res.status(201).json({
      ok: true,
      orderId: order.id,
      telegramSent: false,
      warning: "Buyurtma saqlandi, lekin Telegram xabarida xatolik yuz berdi."
    });
  }
});

app.post("/api/contact", (req, res) => {
  const { name, phone, message } = req.body || {};
  if (!name || !phone || !message) {
    return res.status(400).json({ ok: false });
  }

  res.json({ ok: true, message: "Murojaatingiz qabul qilindi." });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(ROOT, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`MEBELON is running: http://localhost:${PORT}`);
});
